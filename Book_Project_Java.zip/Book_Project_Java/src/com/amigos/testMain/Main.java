package com.amigos.testMain;

import java.util.Scanner;

import com.amigos.models.Book;
import com.amigos.utils.BookUtils;

public class Main {

	public class Reference {
		public static int count = 0;
	}
	
	public static void main(String[] args) {
		Scanner sc=new Scanner (System.in);
		System.out.print("Enter size: ");
		int size=sc.nextInt();
		int choice;
		int count = 0;
		Book[]book=new Book[size];
		do {
			System.out.println("\n1.Add\n2.Display\n3.Search\n4.delete\n5.update\n6.Top 3\n0.Exit");
			System.out.print("Enter your choice: ");
			choice=sc.nextInt();
			switch(choice){
			case 1:
			{
				Book b = BookUtils.addNewPlayer(size);
				book[Reference.count] = b;
				Reference.count++;
				 break;
			}
			case 2:
			{
				
					BookUtils.displayBook(book);
				break;
			}
			
			case 3:
			{
				BookUtils.search(book);
				
				break;
			}
			
			case 4:
			{
				BookUtils.deleted(book);

				break;
			}
			
			case 5:
			{
				BookUtils.updated(book);
				break;
			}
			
			case 6:
			{
				BookUtils.displaytop3(book);
				break;	
			}
			
			case 0:
			{
				System.out.println("Thank you!!!");
				break;
			}
			default:
			{
				System.out.println("Wrong choice");
				break;
			}
			}
			
		}while(choice!=0);
		
	   sc.close();
	}

}



