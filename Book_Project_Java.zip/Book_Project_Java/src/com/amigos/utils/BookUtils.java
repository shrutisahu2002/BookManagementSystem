package com.amigos.utils;

import java.util.Scanner;

import com.amigos.models.Book;
import com.amigos.testMain.Main.Reference;

public class BookUtils {
	static Scanner sc=new Scanner(System.in);
   
  
	public static Book addNewPlayer(int size) {
		
		if(Reference.count < size) {
			System.out.print("BOOK Id:");
	    	int bookid=sc.nextInt();
	    	System.out.print("BOOK NAME:");
	    	String bookname=sc.next();
	    	System.out.print("AUTHOR NAME:");
	    	String authorname=sc.next();
	    	sc.nextLine();
	    	System.out.print("PRICE:");
	    	int price=sc.nextInt();
	    	System.out.print("RATING:");
	    	int rating=sc.nextInt();
	    	
	    	
	    	Book b=new Book(bookid,bookname,authorname,price,rating);
	    	return b;
		}
		else {
			System.out.println("Size Out of Index");
		}
		return null ;
	}
	//////////////////////////////////////////////////////////////
	public static void displayBook(Book[] book) {
    	
	    
        for (int i = 0; i < Reference.count; i++) {
        	System.out.println("\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\");
        	System.out.println("BOOK Id: "+book[i].getBookid());
        	System.out.println("BOOK NAME: "+book[i].getBookname());
        	System.out.println("AUTHOR NAME: "+book[i].getAuthorname());
        	System.out.println("PRICE: "+book[i].getPrice());
        	System.out.println("RATING: "+book[i].getRating());
        }
    }
	
//////////////////////////////////////////////////////////////////
	public static void display(Book b) {
		System.out.println("\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\");
    	System.out.println("BOOK Id: "+b.getBookid());
    	System.out.println("BOOK NAME: "+b.getBookname());
    	System.out.println("AUTHOR NAME: "+b.getAuthorname());
    	System.out.println("PRICE: "+b.getPrice());
    	System.out.println("RATING: "+b.getRating());
		
	}
//////////////////////////////////////////////////////////////////////
	private static void displayTop3Book(Book[] book) {
		for (int i = 0; i < 3; i++) {
        	System.out.println("\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\");
        	System.out.println("BOOK Id: "+book[i].getBookid());
        	System.out.println("BOOK NAME: "+book[i].getBookname());
        	System.out.println("AUTHOR NAME: "+book[i].getAuthorname());
        	System.out.println("PRICE: "+book[i].getPrice());
        	System.out.println("RATING: "+book[i].getRating());
        }
		
	}
	
	/////////////////////////////////////////////////////////////////
	public static void search(Book[] book) {
	    int bid, result;
	    String name;
	    System.out.println("Select a option to be used to search a Book:");
	    System.out.println("1.Book id.\t2.Book name\t3.Author Name");
	    System.out.print("Enter choice: ");
	    int a = sc.nextInt();
	    if (a == 1) {
	        System.out.println("\nEnter the Book Id. of the Book");
	         bid = sc.nextInt();
	        result = searchByBookId(book,bid);
	        if (result == -1) {
	            System.out.println("Record not found");
	        } else {
	            display(book[result]);
	        }
	    }
	    if (a == 2) {
	        System.out.println("Enter the Book Name. of the Book");
	        name = sc.next();
	        result = searchByBookName(book, name);
	        if (result == -1) {
	            System.out.println("record not found");

	        } else {
	            display(book[result]);
	        }
	    }
	    
	    if (a == 3) {
	        System.out.println("Enter the Author Name. of the Book");
	        name = sc.next();
	        result = searchByAuthorName(book, name);
	        if (result == -1) {
	            System.out.println("record not found");

	        } else {
	            display(book[result]);
	        }
	    }
	    
	}
	    
	    
	    public static int searchByBookId(Book[] book,int bid)
	    {
	    	
	    	for (int i=0;i<Reference.count;i++)
	    	{
	    		if(book[i].getBookid()==bid)
	    		{
	    			System.out.println("Book Id Present At Index "+i);
	    			return i;
	    		}
	    	}
	    	return -1;
	    }
	    /////////////
	    public static int searchByBookName(Book[] book, String name) {
	        for (int i = 0; i < Reference.count; i++) {
	            if (book[i].getBookname().equals(name)) {
	            	System.out.println("Book Name Present At Index "+i);
	                return i;
	            }
	        }
	        
	        return -1;
	    }
	    //////////////
	    public static int searchByAuthorName(Book[] book, String authorname) {
	        for (int i = 0; i < Reference.count; i++) {
	            if (book[i].getAuthorname().equals(authorname)) {
	            	System.out.println("Author Name Present At Index "+i);
	                return i;
	            }
	        }
	        
	        return -1;
	    }
	    
	
	public static void deleted(Book[] book) {
		int bid, result;
	    String name;
	    String authorname;
	    System.out.println("Select a option to be used to delete a Book:");
	    System.out.println("1.Book id.\t2.Book name\t3.Author Name");
	    System.out.print("Enter choice: ");
	    int a = sc.nextInt();
	    if (a == 1) {
	    	
	    	System.out.print("Enter Book id ,Do you want to delete: ");
	    	bid=sc.nextInt();
			 result = searchByBookId(book,bid);
	        if (result == -1) {
	            System.out.println("record not found");

	        } else {
	        	while(result<Reference.count-1){   
					book[result]=book[result+1]; 
					result++; 
	 	 	  } 
	        	System.out.println("Deleted Successfully!!!");
	        	Reference.count--;
	        }
			}
	    if (a == 2) {
	    	System.out.print("Enter Book Name ,Do you want to delete: ");
	    	name=sc.next();
			 result = searchByBookName(book,name);
	        if (result == -1) {
	            System.out.println("record not found");

	        } else {
	        	while(result<Reference.count-1){   
					book[result]=book[result+1]; 
					result++; 
	 	 	  } 
	        	System.out.println("Deleted Successfully!!!");
	        	Reference.count--;
	        }
	    }
	    
	    if (a == 3) {
	    	System.out.print("Enter Author name ,Do you want to delete: ");
	    	authorname=sc.next();
			 result = searchByAuthorName(book,authorname);
	        if (result == -1) {
	            System.out.println("record not found");

	        } else {
	        	while(result<Reference.count-1){   
					book[result]=book[result+1]; 
					result++; 
	 	 	  } 
	        	System.out.println("Deleted Successfully!!!");
	        	Reference.count--;
	        }
	    }
	}
		
	public static void updated(Book[] book) {
		int bid, result;
		double price = 0,rate=0;
	    String name;
	    String authorname;
	    System.out.println("Select a option to be used to Update a Book:");
	    System.out.println("1.Book id.\t2.Book name\t3.Author Name\t4.Price\t5.Rating");
	    System.out.print("Enter choice: ");
	    int a = sc.nextInt();
	    if (a == 1) {
	    	System.out.print("Enter Book id ,Do you want to update: ");
	    	bid=sc.nextInt();
			 result = searchByBookId(book,bid);
	        if (result == -1) {
	            System.out.println("record not found");

	        } else {
	        	System.out.print("Enter update Book id: ");
		    	int b=sc.nextInt();
	        	book[result].setBookid(b);
	 	 	  } 
	        System.out.println("Update Successfully!!!");
	        	
	        }
	    
	    else if (a == 2) {
	    	System.out.print("Enter Book Name ,Do you want to update: ");
	    	name=sc.next();
			 result = searchByBookName(book,name);
	        if (result == -1) {
	            System.out.println("record not found");

	        } 
	        else {
	        	System.out.print("Enter update Book Name: ");
		    	String b=sc.next();
	        	book[result].setBookname(b);
	 	 	  }
	        
	        System.out.println("Update Successfully!!!");
	        	
	        }
	    
	    else if (a == 3) {
	    	System.out.print("Enter Author name ,Do you want to update: ");
	    	authorname=sc.next();
			 result = searchByAuthorName(book,authorname);
	        if (result == -1) {
	            System.out.println("record not found");

	        } else {
	        	System.out.print("Enter update Book Author Name: ");
		    	String b=sc.next();
	        	book[result].setAuthorname(b);
	 	 	  } 
	        	System.out.println("Update Successfully!!!");
	        }
	    
	    else if (a == 4) {
    	
    	System.out.print("Enter Book id ,Do you want to update: ");
    	bid=sc.nextInt();
		 result = searchByBookId(book,bid);
        if (result == -1) {
            System.out.println("record not found");

        } else {
        	System.out.print("Enter update price: ");
	    	int b=sc.nextInt();

        	book[result].setPrice(b);
 	 	  } 
        System.out.println("Update Successfully!!!");
        	
        }
	    else if (a == 5) {
		    	
		    	System.out.print("Enter Book id ,Do you want to update: ");
		    	bid=sc.nextInt();
				 result = searchByBookId(book,bid);
		        if (result == -1) {
		            System.out.println("record not found");

		        } else {
		        	System.out.print("Enter update Rating: ");
			    	int b=sc.nextInt();

		        	book[result].setRating(b);
		 	 	  } 
		        System.out.println("Update Successfully!!!");
		        	
		        }
	     else{ 
	    	     System.out.println("\nInvalid option!!!");
				 updated(book);
			}
		
	}
	
	public static void displaytop3(Book[] book) {
		 int option; 
		 System.out.println("\nDisplay top 3:\n1.Price\n2.Rating\n");
		 System.out.println("Your option:");
		 option=sc.nextInt();
		 int i,j;
		 Book[] topbooks=new Book[Reference.count];
		 Book temp;
		 for(int a=0;a<Reference.count;a++) {
			 topbooks[a]=book[a];
		 } 
		 if(option==1){ 
				for(j=0;j<Reference.count;j++){
					 for(i=0;i<Reference.count-1;i++){	 
			   	if(topbooks[i].getPrice()<topbooks[i+1].getPrice()){ 
			   	 	temp=topbooks[i];
			   	 topbooks[i]=topbooks[i+1];
			   	topbooks[i+1]=temp; 
			 	  } 
			  } 
			} 
			  displayTop3Book(topbooks); 
			  } 
			   
			  else if(option==2){ 
				  for(j=0;j<Reference.count;j++){
					  for(i=0;i<Reference.count-1;i++){ 
			   	if(book[i].getRating()<book[i+1].getRating()){ 
			   	 	temp=book[i]; 
			   	 	book[i]=book[i+1];
			   	 	book[i+1]=temp; 
			 	  } 
			  } 
			} 
			  displayBook(topbooks); 
			  } 
		else{ 
				System.out.println("\nInvalid option!!!");
				displayTop3Book(topbooks);
			} 
		
	}
	
	public static void scannerclose ()
    {
        sc.close();
    }
}
