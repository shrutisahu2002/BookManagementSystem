package com.amigos.models;

public class Book {
	private int bookid;  
	private String bookname;  	
	private String authorname; 
	private double price;  
	private double rating; 

	 public Book() {
		 this.bookid = 0;
			this.bookname = "null";
			this.authorname = "null";
			this.price = 0;
			this.rating = 0;
	}
	 
	
	public Book(int bookid, String bookname, String authorname, double price, double rating) {
		super();
		this.bookid = bookid;
		this.bookname = bookname;
		this.authorname = authorname;
		this.price = price;
		this.rating = rating;
	}


	public int getBookid() {
		return bookid;
	}


	public void setBookid(int bookid) {
		this.bookid = bookid;
	}


	public String getBookname() {
		return bookname;
	}


	public void setBookname(String bookname) {
		this.bookname = bookname;
	}


	public String getAuthorname() {
		return authorname;
	}


	public void setAuthorname(String authorname) {
		this.authorname = authorname;
	}


	public double getPrice() {
		return price;
	}


	public void setPrice(double price) {
		this.price = price;
	}


	public double getRating() {
		return rating;
	}


	public void setRating(double rating) {
		this.rating = rating;
	}
	
	

}

///////////////////////////////////////////////
//public void display() {
//	
//	 System.out.println("Book id: "+this.getBid());
//	 System.out.println("Book Name: "+this.getBname());
//	 System.out.println("Book Price: "+this.getPrice());
//	 System.out.println("///////////////////////////////////");
//}
//
//
//static Scanner sc=new Scanner(System.in);
//
//public static int search(Book[] b_arr) {
//	 int ele = sc.nextInt();
//	 for(int i=0;i<5;i++) {
//		 if(b_arr[i].getBid()==ele) {
//			 return i;
//
//	 }
//	}
//	 return -1;
//

